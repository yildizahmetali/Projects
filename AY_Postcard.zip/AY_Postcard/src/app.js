// Ahmet Yildiz
// P5.js Postcard Project

let frontvid
let phimage
let frontbg
let frontaudio

let cardfront = true
let cardback = false

let cardswitch = false
let playing = true

function preload() {
    frontvid = createVideo('media/hVideo.mp4')
    //frontvid.size(852,480)
    //frontvid.position(535,265,'fixed')
    frontvid.hide()

    frontaudio = loadSound('media/hAudio.mp3')

    frontbg = loadImage('media/sandbg.jpg')
    phimage = loadImage('media/hawaiiph.jpg')
    backstamp = loadImage('media/hawaii.jpg')
}

function setup() {
    createButtons()
    createCanvas(1080, 720)
}

function draw() {
    frontcard()
    backcard()
    frontvideo()
}

// MY FUNCTIONS
function frontcard() {
    if (cardfront) {
        background(25, 40, 65)
        fill(227, 223, 201)
        strokeWeight(4)
        quad(50,50,1030,50,1030,670,50,670)
        tint(200)
        image(frontbg, 52, 52, 976, 616)
    
        strokeWeight(2)
        rect(115,140,852,480)

        fill(0, 0, 0)
        textSize(40)
        textFont('Times New Roman')
        textAlign(CENTER)
        text('HAWAII POST CARD', 560, 120)
    
        tint(255)
        image(phimage, 115, 140, 852, 480)

        cardfront = false
    }
}

function backcard() {
    if (cardback) {
        background(25, 40, 65)
        fill(227, 223, 201)
        strokeWeight(4)
        quad(50,50,1030,50,1030,670,50,670)

        fill(0,0,0)
        rect(750, 125, 125, 150)
        image(backstamp, 750, 125, 125, 150)
        //mid
        line(540,100,540,620)
        //1
        line(625,400,975,400)
        //2
        line(625,475,975,475)
        //3
        line(625,550,975,550)
        fill(0, 0, 0)
        textSize(35)
        text('Dear Ahmet Yildiz Sr',300,200)
        textSize(25)
        text("Hope you're enjoying your stay in Hawaii, ", 300,300)
        text("can't wait to hang when you get back. Don't", 300,350)
        text("forget to try and get me a souvenir on your", 300,400)
        text("way back. Safe travels, hugs and kisses <3 ", 300,450)
        text('Ahmet Yildiz Jr', 705,390)
        text('3850 Wailea Alanui Dr', 740,465)
        text('Wailea, HI 96753', 710,545)
        
        cardback = false
    }
}

function frontvideo() {
    tint(255)
    vidphoto = image(frontvid, 115, 140, 852, 480)
}

function createButtons() {
    vidbutton = createButton('Play Video')
    vidbutton.position(-390,0, 'relative')
    vidbutton.size(100,20)
    vidbutton.mousePressed(playvideo)

    audiobutton = createButton('Play Audio')
    audiobutton.position(-390, 0, 'relative')
    audiobutton.size(100,20)
    audiobutton.mousePressed(playaudio)

    cardbutton = createButton('Back of Card')
    cardbutton.position(390, 0, 'relative')
    cardbutton.size(100,20)
    cardbutton.mousePressed(frontbackbutton)
}

function frontbackbutton() {
    if (cardswitch) {
        cardswitch = false
        cardbutton.html('Back of Card')
        cardfront = true
    } else {
        cardswitch = true
        cardbutton.html('Front of Card')
        cardback = true
    }
}

function playvideo() {
    if (playing) {
        frontvid.play()
        frontvid.loop()
        playing = false
        vidbutton.html('Pause Video')
    } else {
        frontvid.pause()
        playing = true
        vidbutton.html('Play Video')
    } 
}

function playaudio() {
    if (playing) {
        frontaudio.play()
        frontaudio.loop()
        playing = false
        audiobutton.html('Pause Audio')
    } else {
        frontaudio.stop()
        playing = true
        audiobutton.html('Play Audio')
    }
}
