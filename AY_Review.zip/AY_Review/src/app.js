// Ahmet Yildiz
// Review/Port Project

// Converted from Processing to P5.js
// Processing example can be found within the folder (RecursiveTreeEx)
// Example: http://formandcode.com/code-examples/repeat-recursive-tree
// Modified example to make render more visually pleasing before porting

let dotSize = 10
let angleOffsetA
let angleOffsetB

function setup() {
    createCanvas(1280, 720)
    noStroke()
    fill(255, 0, 0)
    smooth()
    // recursion trees rendered/s (> num = more trees)
    frameRate(10)
}

function draw() {
    background(25,25,25)
    translate(width/2,height)
    seed1(dotSize, radians(270), 0, 0)

    angleOffsetA = radians(random(-PI, PI))
    angleOffsetB = radians(random(0,45))
}

function seed1(dotSize, angle, x, y) {
    if (dotSize > 1.0) {
        r = random(0, 1.0)

        // 98% chance to run
        if (r > 0.02) {
            ellipse(x, y, dotSize, dotSize)
            let newx = x + cos(angle) * dotSize
            let newy = y + sin(angle) * dotSize
            seed1(dotSize * 0.99, angle - angleOffsetA, newx, newy)
        } 
        // 2% chance to run
        else {
            ellipse(x, y, dotSize, dotSize)
            let newx = x + cos(angle)
            let newy = y + sin(angle)
            seed2(dotSize * 0.99, angle + angleOffsetA, newx, newy)
            seed1(dotSize * 0.60, angle + angleOffsetB, newx, newy)
            seed2(dotSize * 0.50, angle - angleOffsetB, newx, newy)
        }
    }
}

function seed2(dotSize, angle, x, y) {
    if (dotSize > 1.0) {
        r = random(0, 1.0)

        // 95% chance to run
        if (r > 0.05) {
            ellipse(x, y, dotSize, dotSize)
            let newx = x + cos(angle) * dotSize
            let newy = y + sin(angle) * dotSize
            seed2(dotSize * 0.99, angle + angleOffsetA, newx, newy)
        }
        // 5% chance to run
        else {
            ellipse(x, y, dotSize, dotSize)
            let newx = x + cos(angle)
            let newy = y + sin(angle)
            seed1(dotSize * 0.99, angle + angleOffsetA, newx, newy)
            seed2(dotSize * 0.60, angle + angleOffsetB, newx, newy)
            seed1(dotSize * 0.50, angle + angleOffsetB, newx, newy)
        }
    }
}







