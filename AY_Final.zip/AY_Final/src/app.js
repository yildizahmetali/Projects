// Ahmet Yildiz
// Final Project
// Snake Game

let canvas
let myScore = 0
let gSpeed = 20

const xStart = 400
const yStart = 400
const gameDiff = 10

let sLength = 5
let snakeDir = 'right'

let xCor = []
let yCor = []

let xFruit = 0
let yFruit = 0


function setup() {

    canvas = createCanvas(800,800)
    canvas.style('display', 'block')
    canvas.style('margin', 'auto')
    canvas.style('margin-top', '2rem')

    // white bg to check if draw() runs
    background(255,255,255)

    // speed of the snake game
    frameRate(gSpeed)

    stroke(255,0,0)
    updateFruit()
    for (let i = 0; i < sLength; i++) {
        stroke(0,255,0)
        xCor.push(xStart + i * gameDiff)
        yCor.push(yStart)
    }

}

function draw() {
    strokeWeight(10)
    background(50,50,50)
    for (let i = 0; i < sLength - 1; i++) {
        // rect(xCor[i], yCor[i], 5)
        // rect(xCor[i + 5], yCor[i + 5], 10)
        stroke(0,255,0)
        line(xCor[i], yCor[i], xCor[i + 1], yCor[i + 1])
    }
    stroke(255,0,0)
    updateSnake()
    checkGame()
    checkFruit()

    strokeWeight(0)
    fill(255)
    textSize(20)
    text(myScore, 10,30)
}

// Keyboard controller for updating snake position
function keyPressed() {
    switch (keyCode) {
        case 68:
            if (snakeDir !== 'left') {
                snakeDir = 'right'
            }
            break
        case 65:
            if (snakeDir !== 'right') {
                snakeDir = 'left'
            }
            break
        case 87:
            if (snakeDir !== 'down') {
                snakeDir = 'up'
            }
            break
        case 83:
            if (snakeDir !== 'up') {
                snakeDir = 'down'
            }
            break
    }
}

// My Functions

// Updates the coordinates of the fruit randomly
function updateFruit() {
    strokeWeight(10)
    stroke(255,0,0)
    xFruit = floor(random(10, (width - 100) / 10)) * 10
    yFruit = floor(random(10, (height -100) / 10)) * 10
}

// Snake controller for updating its location
function updateSnake() {
    for (let i = 0; i < sLength; i++) {
        xCor[i] = xCor[i + 1]
        yCor[i] = yCor[i + 1]
    }
    switch (snakeDir) {
        case 'right':
            xCor[sLength - 1] = xCor[sLength - 2] + gameDiff
            yCor[sLength - 1] = yCor[sLength - 2]
            break
        case 'left':
            xCor[sLength - 1] = xCor[sLength - 2] - gameDiff
            yCor[sLength - 1] = yCor[sLength - 2]
            break
        case 'up':
            xCor[sLength - 1] = xCor[sLength - 2]
            yCor[sLength - 1] = yCor[sLength - 2] - gameDiff
            break
        case 'down':
            xCor[sLength - 1] = xCor[sLength - 2]
            yCor[sLength - 1] = yCor[sLength - 2] + gameDiff
    }
}

// Checks the position of fruit in relation to snake for score
function checkFruit() {
    point(xFruit, yFruit)
    if (xCor[xCor.length - 1] === xFruit && yCor[yCor.length - 1] === yFruit) {
        xCor.unshift(xCor[0])
        yCor.unshift(yCor[0])
        myScore++
        sLength++
        updateFruit()
    }
}

// Checks the game status of game, when game over, displays alert with score
function checkGame() {
    if (
        xCor[xCor.length - 1] > width ||
        xCor[xCor.length - 1] < 0 ||
        yCor[yCor.length - 1] > height ||
        yCor[yCor.length - 1] < 0 ||
        checkCollision()
    )   {
        alert('Game Over \nScore: ' + myScore + '\n\nPress OK to Restart')
        window.location.reload()
        noLoop()
    }
}

// Checks the collision of snake in relation to itself for the game status
function checkCollision() {
    const snakeHeadX = xCor[xCor.length - 1]
    const snakeHeadY = yCor[yCor.length - 1]
    for (let i = 0; i < xCor.length - 1; i++) {
        if (xCor[i] === snakeHeadX && yCor[i] === snakeHeadY) {
            return true
        }
    }
}
