// Ahmet Yildiz
// Extra Credit Assignment

let canvas

let mybg
let myText
let rspeed

function preload() {
    mybg = loadImage('../media/bg.jpg')    
}

function setup() {
    canvas = createCanvas(1280,720,WEBGL)
    background(100,100,100)
    frameRate(60)

    myText = createGraphics(400,400)
    myText.textFont('NORMAL')
    myText.textAlign(CENTER)
    myText.textSize(20)
    myText.fill(255)
    myText.stroke(0)
    myText.strokeWeight(1)
    myText.text('Press Space-Bar to pause rotation \n Press 1-2 to change rotation speed',200,200);


    rspeed = 0.01
}

function draw() {
    background(16,32,64)
    myBytes()
}


function keyPressed() {
    if (keyCode === 32) {
        rspeed = 0
        console.log(rspeed)
    }

    if (keyCode === 50) {
        rspeed += 0.01
        console.log(rspeed)
    }

    if (keyCode === 49) {
        rspeed -= 0.01
        console.log(rspeed)
    }
}

// my functions

function myBytes() {
        push()
        translate(0,0,0)
        texture(mybg)
        noStroke()
        plane(canvas.width,canvas.height)
        pop()

        push()
        fill(16,32,64)
        translate(0,-100)
        rotateX((frameCount * rspeed * 0.000001))
        rotateY(frameCount * rspeed)
        rotateZ(frameCount * rspeed * 0.00001)
        stroke(205,25,25)
        strokeWeight(0.25)
        texture(mybg)
        sphere(130)
        pop()

        push()
        stroke(255)
        strokeWeight(0)
        texture(myText)
        translate(0,150)
        plane(400, 400)
        pop()  
}