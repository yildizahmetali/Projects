// Ahmet Yildiz
// Extra Credit Assignment

let canvas

let img1
let img2
let img3
let img4
let img5

let sLoop = true
let myArray = []

function preload() {
    img1 = loadImage('../media/img1.jpeg')
    img2 = loadImage('../media/img2.jpeg')
    img3 = loadImage('../media/img3.jpeg')
    img4 = loadImage('../media/img4.jpg')
    img5 = loadImage('../media/img5.jpg')
}

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)
    frameRate(60)

    num = 100
    changeDirection = false

    myArray[0] = [img1,400,0,160,160,true]
    myArray[1] = [img2,500,160,160,160,false]
    myArray[2] = [img3,100,320,160,160,true]
    myArray[3] = [img4,600,480,160,160,false]
    myArray[4] = [img5,300,640,160,160,true]
    cDir = false
}

function draw() {

    background(16,32,64)

    imageSlider(0)
    imageSlider(1)
    imageSlider(2)
    imageSlider(3)
    imageSlider(4)

    console.log(myArray)

}

function keyPressed() {
    if (keyCode === 32) {
        if (sLoop === true) {
            noLoop()
            sLoop = false
        } else {
            loop()
            sLoop = true
        }
    }
}

// my functions
function imageSlider(num) {

    image(myArray[num][0],myArray[num][1],myArray[num][2],myArray[num][3],myArray[num][4])
    if (myArray[num][1] > width - myArray[num][3]) {
        myArray[num][5] = true
    } else if (myArray[num][1] <= 0) {
        myArray[num][5] = false
    }

    if (myArray[num][1] >= 0 && myArray[num][5] == false) {
        myArray[num][1] = myArray[num][1] + 1
    } else if (myArray[num][5] == true) {
        myArray[num][1] = myArray[num][1] - 1
    }

}