// Ahmet Yildiz
// Extra Credit Assignment

let canvas

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)

    textAlign(CENTER)
    textSize(20)
    fill(255)
}

function draw() {
    background(16,32,64)
    text('Use Navigation Bar to view Extra Credit Challenges', canvas.width / 2, canvas.height / 2.5)
    text('🙃', canvas.width / 2, canvas.height / 2)
}