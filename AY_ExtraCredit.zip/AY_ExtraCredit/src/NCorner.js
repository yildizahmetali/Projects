// Ahmet Yildiz
// Extra Credit Assignment

let canvas
let rNum1
let rNum2
let rNum3
let rNum4

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)
    frameRate(30)
    rNum1 = random(2,10)
    rNum2 = random(2,10)
    rNum3 = random(2,10)
    rNum4 = random(2,10)
}

function draw() {

    // smoothen animation
    clear()
    background(16,32,64)

    fill(255)
    textSize(20)
    textAlign(CENTER, CENTER)
    text("Was a bit confused on this challenge's prompt", 400,375)
    text("thus, created a program that generates random", 400,400)
    text("polygons with arbitrary corners within canvas", 400,425)

    fill(255)
    // top left polygon
    push()
    translate(100, 100)
    rotate(frameCount)
    nCorner(0,0,100,rNum1)
    pop()
    // top right polygon
    push()
    translate(700, 100)
    rotate(frameCount)
    nCorner(0,0,100,rNum2)
    pop()

    // bottom right polygon
    push()
    translate(700, 700)
    rotate(frameCount)
    nCorner(0,0,100,rNum3)
    pop()

    // bottom left polygon
    push()
    translate(100, 700)
    rotate(frameCount)
    nCorner(0,0,100,rNum4)
    pop()
}

function nCorner(x, y, radius, n) {
    let angle = TWO_PI / n
    beginShape()
    for (let i = 0; i < TWO_PI; i+= angle) {
        let shapeX = x + cos(i) * radius
        let shapeY = y + sin(i) * radius
        vertex(shapeX, shapeY)
    }
    endShape(CLOSE)
}