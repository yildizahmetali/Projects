// Ahmet Yildiz
// Extra Credit Assignment
let canvas
let mySound
let myImage

function preload() {
    mySound = loadSound('../media/hello.mp3')
    myImage = loadImage('../media/c3po.jpeg')
}

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)
}

function draw() {

    background(16,32,64)
    imageMode(CENTER)
    image(myImage, canvas.width / 2, 600,250,250)

    fill(255)
    textAlign(CENTER)
    textSize(20)
    text('Press 1 to play audio with 1x playback speed', canvas.width / 2, 100)
    text('Press 2 to play audio with 2x playback speed', canvas.width / 2, 200)
    text('Press 3 to play audio with 0.5x playback speed', canvas.width / 2, 300)
    text('Press 4 to play audio with reverse playback speed', canvas.width / 2, 400)
}

function keyPressed() {
    if (keyCode === 49) {
        mySound.stop()
        mySound.playbackRate = 1.0
        mySound.play()
    } else if (keyCode === 52) {
        mySound.stop()
        fetch("../media/hello.mp3", process)
        // process audio buffer with decoder
        function process(file) {
            var actx = new (window.AudioContext || window.webkitAudioContext)
            actx.decodeAudioData(file, function(buffer) {     
                var src = actx.createBufferSource(),   
                channel, tmp, i, t = 0, len, len2
                // reverse audio channels
                while (t < buffer.numberOfChannels) {    
                    channel = buffer.getChannelData(t++)
                    len = channel.length - 1       
                    len2 = len >>> 1               
                    for (i = 0; i < len2; i++) {
                    tmp = channel[len - i]      
                    channel[len - i] = channel[i]
                    channel[i] = tmp             
                    }
                }
                // play audio buffer
                src.buffer = buffer
                src.connect(actx.destination)
                if (!src.start) {
                    src.start = src.noteOn
                }
                src.start(0)
            })
        }

        // ajax loader for audio buffer
        function fetch(url, callback) {
        var xhr = new XMLHttpRequest()
            try {
                xhr.open("GET", url)
                xhr.responseType = "arraybuffer"
                xhr.onerror = function() {alert("Network error")}
                xhr.onload = function() {
                    if (xhr.status === 200) callback(xhr.response)
                        else alert(xhr.statusText)
                }
                xhr.send()
            }   
            catch (err) {alert(err.message)}
        }

    } else if (keyCode === 50) {
        mySound.stop()
        mySound.playbackRate = 2.0
        mySound.play()
    } else if (keyCode === 51) {
        mySound.stop()
        mySound.playbackRate = 0.5
        mySound.play()
    }
}