// Ahmet Yildiz
// Extra Credit Assignment

let canvas

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)
}

// Continous loop, draws the shapes
function draw() {
    FourCornerConditional()
}

// My Functions

function FourCornerConditional() {
    background(16,32,64)
    fill(255)
    ellipse(50,50,100)
    triangle(700,100,750,0,800,100)
    quad(650,750,750,700,800,750,750,800)
    rect(0,700,100,100,20)


}