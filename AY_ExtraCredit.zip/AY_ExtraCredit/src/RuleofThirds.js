// Ahmet Yildiz
// Extra Credit Assignment

let canvas
let myRock

function preload() {
    myRock = loadImage('../media/rock.jpg')
}

function setup() {
    canvas = createCanvas(1280,720)
    background(100,100,100)
    image(myRock,0,0, 1280, 720)
}

function draw() {
    stroke(255,0,0)
    strokeWeight(1)
    line(canvas.width / 3,0,canvas.width / 3, canvas.height)
    line((canvas.width / 3) * 2,0,(canvas.width / 3) * 2, canvas.height)

    line(0, canvas.height / 3, canvas.width, canvas.height / 3)
    line(0, (canvas.height / 3) * 2, canvas.width, (canvas.height / 3) * 2)

    stroke(0)
    strokeWeight(1)
    textSize(24)
    fill(255)
    text('With the RO3 lines on this image, we can see the rock occupying the bottom-right 4 sections of the grid', 20, 75)
    text('As a result, leaving me plenty of room throughout other parts of the image to write this reflection here :)', 20, 100)

}