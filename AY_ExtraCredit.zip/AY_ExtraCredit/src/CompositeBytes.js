// Ahmet Yildiz
// Extra Credit Assignment

let canvas

let mybg
let donut
let myText
let myRotation

function preload() {
    donut = loadImage('../media/donut.jpg')
    mybg = loadImage('../media/bakery.jpg')
}

function setup() {
    canvas = createCanvas(800,800, WEBGL)
    background(100,100,100)
    frameRate(60)

    myText = createGraphics(400,400)
    myText.textFont('NORMAL')
    myText.textAlign(CENTER)
    myText.textSize(20)
    myText.fill(255)
    myText.stroke(0)
    myText.strokeWeight(1)
    myText.text('Press Space-Bar to pause rotation \n Press 1-2 to change rotation speed',200,200);

    myRotation = 0.01
}

function draw() {
    background(16,32,64)

    myDonuts()

}

function keyPressed() {
    if (keyCode === 32) {
        myRotation = 0
        console.log(myRotation)
    }

    if (keyCode === 49) {
        myRotation -= 0.01
        console.log(myRotation)
    }

    if (keyCode === 50) {
        myRotation += 0.01
        console.log(myRotation)
    }

}

function myDonuts() {
    push()
    translate(0,0,-400)
    texture(mybg)
    noStroke()
    plane(canvas.width + 460, canvas.height + 460)
    pop()

    // top left
    push()
    texture(donut)
    translate(-200,-250)
    stroke(0)
    strokeWeight(0)
    rotateX(0.60)
    rotateY(0.25)
    rotateZ(frameCount * -myRotation)
    torus(100, 50)
    pop()

    // top right
    push()
    texture(donut)
    translate(200,-250)
    stroke(0)
    strokeWeight(0)
    rotateX(0.70)
    rotateY(-0.25)
    rotateZ(frameCount * -myRotation)
    torus(50, 25)
    pop()

    // bottom right
    push()
    texture(donut)
    translate(150,0)
    stroke(0)
    strokeWeight(0)
    rotateX(1)
    rotateY(-0.25)
    rotateZ(frameCount * myRotation)
    torus(100, 50)
    pop()

    //bottom left
    push()
    texture(donut)
    translate(-225,25)
    stroke(0)
    strokeWeight(0)
    rotateX(1.1)
    rotateY(0.50)
    rotateZ(frameCount * myRotation)
    torus(60, 30)
    pop()

    // background
    push()
    stroke(255)
    strokeWeight(0)
    texture(myText)
    translate(0,250)
    plane(400, 400)
    pop() 


}