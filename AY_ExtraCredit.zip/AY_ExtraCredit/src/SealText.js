// Ahmet Yildiz
// Extra Credit Assignment

let canvas

let myWord
let myWordArray = []
let radius
let theta
let clockwise

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)

    myWord = "AHMETYILDIZAHMETYILDIZAHMETYILDIZAHMETYILDIZ"

    frameRate(60)
    textAlign(CENTER)
    textSize(20)
    fill(255)

    radius = 300
    theta = 0
    clockwise = true
    myLoop = true

    myWordArray = myWord.split('')

    console.log(myWord)
    console.log(myWordArray)
}

function draw() {

    background(16,32,64)
    if (clockwise) {
        textcircle()
        textAlign(CENTER)
        text('AHMETYILDIZ',0,-25)
        text('Space-Bar to switch rotation',0,25)
    } else {
        ctextcircle()
        textAlign(CENTER)
        text('AHMETYILDIZ',0,-25)
        text('Space-Bar to switch rotation',0,25)
    }
}

function keyPressed() {
    if (keyCode === 32) {
        if (clockwise === true) {
            clockwise = false
        } else {
            clockwise = true
        }
    }

    // pause loop, debugging
    if (keyCode === 49) {
        if (myLoop === true) {
            noLoop()
            myLoop = false
        } else {
            loop()
            myLoop = true
        }
    }
}

// my functions

function textcircle() {
    background(16,32,64)
    translate(width / 2, height / 2);
    let x = radius * cos(theta);
    let y = radius * sin(theta);
  
    for (let i = 0; i < myWordArray.length; i++) {
        theta++
        rotate(HALF_PI / 11);
        text(myWordArray[i], x, y);
    }
}

function ctextcircle() {
    background(16,32,64)
    translate(width / 2, height / 2);
    let x = radius * cos(theta);
    let y = radius * sin(theta);
  
    for (let i = 0; i < myWordArray.length; i++) {
        theta--
        rotate(HALF_PI / 11);
        text(myWordArray[i], x, y);
    }
}
