// Ahmet Yildiz
// Extra Credit Assignment

let canvas

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)
}

// Continous loop, draws the ellipses
function draw() {
    FourCorners()
}

// My Functions

function FourCorners() {
    background(16,32,64)
    fill(255)
    ellipse(50,50,100)
    ellipse(750,50,100)
    ellipse(750,750,100)
    ellipse(50,750,100)
}