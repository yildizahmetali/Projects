// Ahmet Yildiz
// Extra Credit Assignment

let canvas

let filterImage
let myFilter

function preload() {
    filterImage = loadImage('../media/filter.jpg')
}

function setup() {
    canvas = createCanvas(1280,720)
    background(100,100,100)
    myFilter = OPAQUE
}

function draw() {

    background(16,32,64)
    image(filterImage, 0, 0, canvas.width, canvas.height)
    filter(myFilter)

    textAlign(CENTER)
    textSize(20)
    fill(255)
    stroke(0)
    strokeWeight(25)
    text('Press 1-5 to cycle through image filters', canvas.width / 2,125)
}

function keyPressed() {
    if (keyCode === 49) {1
        myFilter = OPAQUE
    }
    if (keyCode === 50) {
        myFilter = GRAY
    }
    if (keyCode === 51 ) {
        myFilter = DILATE
    }
    if (keyCode === 52 ) {
        myFilter = INVERT
    }
    if (keyCode === 53 ) {
        myFilter = THRESHOLD
    }     
}