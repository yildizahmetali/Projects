// Ahmet Yildiz
// Extra Credit Assignment

let canvas
let leaf
let ease
let fall

let x = 1
let y = 1

function preload() {
    fall = loadImage('../media/fall.jpg')
}

function setup() {
    canvas = createCanvas(800,800)
    background(100,100,100)

    ease = 0.025
    leaf = new Leaf()
}

function draw() {
    background(16,32,64)
    image(fall,0,0,canvas.width,canvas.height)

    textAlign(CENTER)
    fill(255)
    textSize(20)
    text('Drag mouse within canvas to move Loose Leaf', canvas.width / 2, 700)

    leaf.move()
    leaf.display()

}

// Leaf Object class

class Leaf {
    constructor() {
        this.x = 1
        this.y = 1
        this.diameter = random(10,30)
        this.speed = 5
    }

    move() {
        this.x = mouseX
        let dx = this.x - x
        x += dx * ease

        this.y = mouseY
        let dy = this.y - y
        y += dy * ease


    }

    display() {

        fill(92,64,51)
        strokeWeight(2)
        ellipse(x,y+45,10,25)

        stroke(0,0,0)
        fill(0,100,0)
        strokeWeight(2)
        ellipse(x,y,50,100)

        strokeWeight(1)
        line(x,y-50,x,y+50)

        strokeWeight(1)
        line(x,y-20,x+20,y-30)
        line(x,y-20,x-20,y-30)

        line(x,y,x+25,y-10)
        line(x,y,x-25,y-10)

        line(x,y+20,x+25,y+10)
        line(x,y+20,x-25,y+10)

        line(x,y+40,x+20,y+30)
        line(x,y+40,x-20,y+30)


        // ellipse(this.x,this.y,this.diameter,this.diameter)
    }

}

