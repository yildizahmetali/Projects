var bird;
var topPipe;
var botPipe;
var GAP_SIZE = 200;
var score = 0;

var bimg
var bgimg

var x1 = 0
var x2
var scrollSpeed = 5

function preload() {
  bimg = loadImage('media/bird.jpg')
  bgimg = loadImage('media/bg.jpg')
}


function setup() {
  createCanvas(1280, 720);
  x2 = width
  noStroke();
  textSize(32);
  frameRate(60)

  matter.init();
  matter.changeGravity(0,2)

  // bird = Bodies.rectangle(100,200,50,50)
  bird = matter.makeBall(width/20, height / 2, 50, 50)

  makePipes();
}

function mousePressed() {
  bird.setVelocityY(-10);
}

function draw() {
  background(50)
  tint(100)
  image(bgimg, x1, 0, width, height)
  image(bgimg, x2, 0, width, height)

  x1 -= scrollSpeed
  x2 -= scrollSpeed

  if (x1 < -width) {
    x1 = width
  }
  if (x2 < -width) {
    x2 = width
  }

  fill(0,255,0)
  topPipe.show()
  botPipe.show()

  fill(255,0,0)
  bird.show()

  fill(255)
  text(score, width - 100, 100)


  var pipePosition = topPipe.getPositionX();
  topPipe.setPositionX(pipePosition - 10);
  botPipe.setPositionX(pipePosition - 10);

  if (topPipe.isOffCanvas()) {
    makePipes();
    score += 1;
  }
  if (bird.isOffCanvas()) {
    alert("Press  OK  to play")
    bird = matter.makeBall(width / 20, height / 2, 50, 50);
    makePipes()
    score = 0;
  }
}

function makePipes() {
  var gap = random(height / 4, 3 * height / 4);
  var gapStart = gap - GAP_SIZE / 2;
  var gapEnd = gap + GAP_SIZE / 2;

  topPipe = matter.makeBarrier(width, gapStart / 2, 80, gapStart, { friction: 0, restitution: 1 });
  botPipe = matter.makeBarrier(width, (height + gapEnd) / 2, 80, height - gapEnd, { friction: 0, restitution: 1 });
}